package com.loja_intrumento_musical.loja;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LojaApplicationTests {

	@Test
	void contextLoads() {
	}

}
